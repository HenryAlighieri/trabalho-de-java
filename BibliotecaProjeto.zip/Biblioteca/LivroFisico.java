public class LivroFisico extends Livro implements Emprestavel {

    public LivroFisico(String titulo, String autor) {
        super(titulo, autor);
    }

    @Override
    public void emprestar() throws Exception {
        if (emprestado) {
            throw new Exception("Livro já está emprestado.");
        }
        emprestado = true;
        System.out.println("Livro físico emprestado com sucesso.");
    }

    @Override
    public void devolver() {
        emprestado = false;
        System.out.println("Livro físico devolvido.");
    }

    @Override
    public void detalhes() {
        System.out.println("Livro Físico: " + titulo + " por " + autor);
    }
}