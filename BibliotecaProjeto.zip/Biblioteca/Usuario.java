public class Usuario {
    private String nome;

    public Usuario(String nome) {
        this.nome = nome;
    }

    public void lerLivro(Livro livro) {
        System.out.println(nome + " está lendo " + livro.getTitulo());
    }
}