public class LivroDigital extends Livro {

    public LivroDigital(String titulo, String autor) {
        super(titulo, autor);
    }

    @Override
    public void detalhes() {
        System.out.println("Livro Digital: " + titulo + " por " + autor);
    }
}