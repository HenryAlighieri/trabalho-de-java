public class Main {
    public static void main(String[] args) {
        LivroFisico livro1 = new LivroFisico("1984", "George Orwell");
        LivroDigital livro2 = new LivroDigital("Clean Code", "Robert C. Martin");

        Usuario usuario = new Usuario("João");

        livro1.detalhes();
        livro2.detalhes();

        try {
            livro1.emprestar();
            usuario.lerLivro(livro1);
            livro1.devolver();
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }

        usuario.lerLivro(livro2);
    }
}